<?php

namespace App\Http\Controllers\Ganaderia;

use App\Http\Controllers\Controller;
use App\Models\Engorda\CorralLote;
use App\Models\Engorda\RacionAlimento;
use App\Models\Ganaderia\Insumo;
use App\Models\Ganaderia\MovimientoInsumo;
use App\Models\Ganaderia\RacionIngrediente;
use App\Services\Ganaderia\InventarioService;
use App\Support\Csv;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class InventarioController extends Controller
{
    public function __construct(private InventarioService $inventario) {}

    public function index(Request $request)
    {
        $insumos = Insumo::query()
            ->when($request->filled('tipo'), fn ($q) => $q->where('tipo', $request->tipo))
            ->when($request->filled('q'), fn ($q) => $q->where(fn ($w) => $w->where('nombre', 'like', "%{$request->q}%")->orWhere('codigo', 'like', "%{$request->q}%")))
            ->when(! $request->boolean('inactivos'), fn ($q) => $q->where('activo', true))
            ->orderBy('tipo')->orderBy('nombre')->get();

        if ($request->input('exportar') === 'csv') {
            return Csv::descargar('inventario_insumos', ['Código', 'Nombre', 'Tipo', 'Unidad', 'Existencia', 'Costo promedio', 'Valor', 'Stock mínimo'],
                $insumos->map(fn ($i) => [$i->codigo, $i->nombre, $i->tipo, $i->unidad, (float) $i->existencia, (float) $i->costo_promedio, $i->valorInventario(), (float) $i->stock_minimo]));
        }

        return view('ganaderia.inventario.index', [
            'insumos'      => $insumos,
            'valorTotal'   => $insumos->sum(fn ($i) => $i->valorInventario()),
            'bajoMinimo'   => Insumo::bajoMinimo()->get(),
            'porCaducar'   => Insumo::lotesPorCaducar(30),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $insumo = Insumo::create($this->validar($request) + ['activo' => true, 'existencia' => 0, 'costo_promedio' => 0]);

        return redirect()->route('inventario.show', $insumo)->with('success', "Insumo {$insumo->nombre} creado. Registra su primera entrada.");
    }

    public function update(Request $request, Insumo $insumo): RedirectResponse
    {
        $insumo->update($this->validar($request, $insumo) + ['activo' => $request->boolean('activo')]);

        return back()->with('success', 'Insumo actualizado.');
    }

    /** Kardex del insumo. */
    public function show(Request $request, Insumo $insumo)
    {
        $movs = $insumo->movimientos()->with(['usuario', 'corral'])
            ->when($request->filled('desde'), fn ($q) => $q->whereDate('fecha', '>=', $request->desde))
            ->when($request->filled('hasta'), fn ($q) => $q->whereDate('fecha', '<=', $request->hasta));

        if ($request->input('exportar') === 'csv') {
            return Csv::descargar('kardex_' . $insumo->codigo, ['Fecha', 'Tipo', 'Cantidad', 'Costo unitario', 'Importe', 'Existencia', 'Lote', 'Caducidad', 'Referencia', 'Usuario'],
                $movs->get()->map(fn ($m) => [$m->fecha->format('Y-m-d'), $m->tipo, (float) $m->cantidad, (float) $m->costo_unitario, $m->importe(),
                    (float) $m->existencia_resultante, $m->lote, $m->fecha_caducidad?->format('Y-m-d'), $m->referencia, $m->usuario->name ?? '']));
        }

        return view('ganaderia.inventario.show', [
            'insumo'   => $insumo,
            'movs'     => $movs->paginate(30)->withQueryString(),
            'corrales' => CorralLote::orderBy('codigo')->pluck('codigo', 'id'),
        ]);
    }

    public function movimiento(Request $request, Insumo $insumo): RedirectResponse
    {
        $data = $request->validate([
            'tipo'            => ['required', Rule::in(['entrada', 'salida', 'ajuste'])],
            'fecha'           => ['required', 'date', 'before_or_equal:today'],
            'cantidad'        => ['required', 'numeric', $request->tipo === 'ajuste' ? 'min:0' : 'gt:0'],
            'costo_unitario'  => ['required_if:tipo,entrada', 'nullable', 'numeric', 'min:0'],
            'lote'            => ['nullable', 'string', 'max:60'],
            'fecha_caducidad' => ['nullable', 'date'],
            'proveedor'       => ['nullable', 'string', 'max:150'],
            'referencia'      => ['nullable', 'string', 'max:150'],
            'corral_lote_id'  => ['nullable', 'exists:corrales_lotes,id'],
            'notas'           => ['nullable', 'string', 'max:500'],
        ], ['cantidad.gt' => 'La cantidad debe ser mayor a cero.', 'costo_unitario.required_if' => 'Indica el costo unitario de la compra.']);

        $extra = collect($data)->only(['fecha', 'lote', 'fecha_caducidad', 'proveedor', 'referencia', 'corral_lote_id', 'notas'])->all();

        try {
            match ($data['tipo']) {
                'entrada' => $this->inventario->entrada($insumo, (float) $data['cantidad'], (float) $data['costo_unitario'], $extra),
                'salida'  => $this->inventario->salida($insumo, (float) $data['cantidad'], $extra),
                'ajuste'  => $this->inventario->ajustar($insumo, (float) $data['cantidad'], $extra + ['referencia' => $data['referencia'] ?? 'Conteo físico']),
            };
        } catch (Exception $e) {
            return back()->withErrors(['cantidad' => $e->getMessage()])->withInput();
        }

        return back()->with('success', 'Movimiento registrado.');
    }

    /* ---------------- Ingredientes de raciones ---------------- */

    public function ingredientes(RacionAlimento $racion): View
    {
        return view('ganaderia.inventario.racion', [
            'racion'  => $racion->load('ingredientes.insumo'),
            'insumos' => Insumo::activos()->where('tipo', 'alimento')->orderBy('nombre')->get(),
        ]);
    }

    public function guardarIngredientes(Request $request, RacionAlimento $racion): RedirectResponse
    {
        $data = $request->validate([
            'ingredientes'              => ['array'],
            'ingredientes.*.insumo_id'  => ['required', 'distinct', 'exists:insumos,id'],
            'ingredientes.*.porcentaje' => ['required', 'numeric', 'gt:0', 'max:100'],
            'actualizar_costo'          => ['nullable', 'boolean'],
        ], ['ingredientes.*.insumo_id.distinct' => 'Un ingrediente está repetido.']);

        $lista = collect($data['ingredientes'] ?? []);
        $suma = round($lista->sum('porcentaje'), 3);
        if ($lista->isNotEmpty() && abs($suma - 100) > 0.5) {
            return back()->withErrors(['ingredientes' => "Los porcentajes suman {$suma}%. Deben sumar 100%."])->withInput();
        }

        $racion->ingredientes()->delete();
        foreach ($lista as $ing) {
            RacionIngrediente::create(['racion_id' => $racion->id] + $ing);
        }

        $mensaje = 'Fórmula guardada.';
        if ($request->boolean('actualizar_costo') && $lista->isNotEmpty()) {
            // costo por kg de cada ingrediente (si se maneja en toneladas, se divide entre 1,000)
            $costo = $racion->fresh('ingredientes.insumo')->ingredientes->sum(fn ($i) => (float) $i->insumo->costo_promedio
                / ($i->insumo->unidad === 'ton' ? 1000 : 1) * (float) $i->porcentaje / 100);
            $racion->update(['costo_por_kg' => round($costo, 2)]);
            $mensaje .= ' Costo por kg actualizado a $ ' . number_format($costo, 2) . ' según el costo promedio de los ingredientes.';
        }

        return back()->with('success', $mensaje);
    }

    /**
     * Planeación de alimento (explosión de materiales):
     * por cada corral activo toma su ración actual y su consumo promedio de los últimos 7 días,
     * y calcula cuántos kg de cada ingrediente se necesitan por día y para cuántos días alcanza la bodega.
     */
    public function planeacion(Request $request): View
    {
        $dias = max(1, min(90, (int) $request->input('dias', 7)));
        $desde = now()->subDays(7)->toDateString();

        $corrales = CorralLote::where('estado', 'Activo')->withCount('ganadosActivos')->orderBy('codigo')->get();
        $necesidades = [];   // insumo_id => kg por día
        $lineas = [];

        foreach ($corrales as $c) {
            $ultimo = \App\Models\Engorda\ConsumoAlimento::with('racion.ingredientes.insumo')
                ->where('corral_lote_id', $c->id)->latest('fecha')->latest('id')->first();
            if (! $ultimo || ! $ultimo->racion) {
                $lineas[] = ['corral' => $c, 'racion' => null, 'cabezas' => $c->ganados_activos_count, 'kg_cab_dia' => null, 'kg_dia' => 0, 'costo_dia' => 0];
                continue;
            }

            $semana = \App\Models\Engorda\ConsumoAlimento::where('corral_lote_id', $c->id)->where('fecha', '>=', $desde)->get();
            $diasConDatos = max(1, $semana->pluck('fecha')->map->toDateString()->unique()->count());
            $kgServidosDia = $semana->sum('kilos_servidos') / $diasConDatos;
            $cabezasProm = max(1, $semana->avg('cabezas_contadas') ?: $c->ganados_activos_count);
            $kgCab = $kgServidosDia / $cabezasProm;
            // Proyección con las cabezas que hay hoy en el corral
            $kgDia = round($kgCab * max(0, $c->ganados_activos_count), 2);

            foreach ($ultimo->racion->ingredientes as $ing) {
                $necesidades[$ing->insumo_id] = ($necesidades[$ing->insumo_id] ?? 0) + $kgDia * (float) $ing->porcentaje / 100;
            }

            $lineas[] = [
                'corral' => $c, 'racion' => $ultimo->racion, 'cabezas' => $c->ganados_activos_count,
                'kg_cab_dia' => round($kgCab, 2), 'kg_dia' => $kgDia,
                'costo_dia' => round($kgDia * (float) $ultimo->racion->costo_por_kg, 2),
                'sin_formula' => $ultimo->racion->ingredientes->isEmpty(),
            ];
        }

        $insumos = Insumo::withTrashed()->whereIn('id', array_keys($necesidades))->get()->keyBy('id');
        $explosion = collect($necesidades)->map(function ($kgDia, $id) use ($insumos, $dias) {
            $ins = $insumos[$id];
            $factor = $ins->unidad === 'ton' ? 1000 : 1;
            $existKg = (float) $ins->existencia * $factor;
            $requerido = $kgDia * $dias;

            return [
                'insumo'      => $ins,
                'kg_dia'      => round($kgDia, 2),
                'requerido'   => round($requerido, 2),
                'existencia'  => round($existKg, 2),
                'cobertura'   => $kgDia > 0 ? round($existKg / $kgDia, 1) : null,
                'faltante'    => round(max(0, $requerido - $existKg), 2),
                'costo_compra'=> round(max(0, $requerido - $existKg) * (float) $ins->costo_promedio / $factor, 2),
            ];
        })->sortBy('cobertura')->values();

        return view('ganaderia.inventario.planeacion', compact('lineas', 'explosion', 'dias'));
    }

    private function validar(Request $request, ?Insumo $insumo = null): array
    {
        $request->merge(['codigo' => mb_strtoupper(trim((string) $request->codigo))]);

        return $request->validate([
            'codigo'       => ['required', 'string', 'max:40', Rule::unique('insumos', 'codigo')->ignore($insumo?->id)],
            'nombre'       => ['required', 'string', 'max:150'],
            'tipo'         => ['required', Rule::in(array_keys(Insumo::TIPOS))],
            'unidad'       => ['required', Rule::in(Insumo::UNIDADES)],
            'stock_minimo' => ['nullable', 'numeric', 'min:0'],
            'dias_retiro'  => ['nullable', 'integer', 'min:0', 'max:365'],
            'presentacion' => ['nullable', 'string', 'max:100'],
            'notas'        => ['nullable', 'string', 'max:500'],
        ]);
    }
}
