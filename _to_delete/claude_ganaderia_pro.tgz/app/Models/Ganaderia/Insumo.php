<?php

namespace App\Models\Ganaderia;

use App\Models\Concerns\Auditable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

/** Alimento, medicamento u otro insumo con existencia y costo promedio. */
class Insumo extends Model
{
    use Auditable, SoftDeletes;

    protected $table = 'insumos';

    public const TIPOS = ['alimento' => 'Alimento / Ingrediente', 'medicamento' => 'Medicamento / Biológico', 'otro' => 'Otro insumo'];
    public const UNIDADES = ['kg', 'ton', 'l', 'ml', 'dosis', 'pieza', 'saco', 'frasco'];

    protected $fillable = [
        'codigo', 'nombre', 'tipo', 'unidad', 'existencia', 'costo_promedio', 'stock_minimo',
        'dias_retiro', 'presentacion', 'activo', 'notas',
    ];

    protected $casts = [
        'existencia'     => 'decimal:3',
        'costo_promedio' => 'decimal:4',
        'stock_minimo'   => 'decimal:3',
        'activo'         => 'boolean',
    ];

    public function movimientos(): HasMany
    {
        return $this->hasMany(MovimientoInsumo::class)->orderByDesc('fecha')->orderByDesc('id');
    }

    public function scopeActivos(Builder $q): Builder
    {
        return $q->where('activo', true);
    }

    public function scopeBajoMinimo(Builder $q): Builder
    {
        return $q->where('activo', true)->where('stock_minimo', '>', 0)->whereColumn('existencia', '<=', 'stock_minimo');
    }

    public function estaBajoMinimo(): bool
    {
        return (float) $this->stock_minimo > 0 && (float) $this->existencia <= (float) $this->stock_minimo;
    }

    public function valorInventario(): float
    {
        return round((float) $this->existencia * (float) $this->costo_promedio, 2);
    }

    /** Lotes con existencia próxima a caducar (entradas con caducidad dentro de N días). */
    public static function lotesPorCaducar(int $dias = 30)
    {
        return MovimientoInsumo::with('insumo')
            ->where('tipo', MovimientoInsumo::ENTRADA)
            ->whereNotNull('fecha_caducidad')
            ->whereDate('fecha_caducidad', '<=', now()->addDays($dias))
            ->whereHas('insumo', fn ($q) => $q->where('existencia', '>', 0)->where('activo', true))
            ->orderBy('fecha_caducidad')
            ->get();
    }

    public function descripcionAuditoria(): string
    {
        return "{$this->codigo} {$this->nombre}";
    }
}
