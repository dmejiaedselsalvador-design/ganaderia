{{--
    Sidebar plegable (compartido por todas las plantas).

    Parámetros:
      $marca     = ['icono' => 'fa-cow', 'titulo' => 'Ganadería<span>System</span>', 'subtitulo' => '...', 'ruta' => 'welcome']
      $principal = [ [permiso|null, ruta, patrón(es), icono, texto], ... ]           (siempre visibles)
      $grupos    = [ 'Título' => ['icono' => 'fa-...', 'items' => [ [ ... ], ... ]], ... ]
      $tema      = ['texto' => 'text-emerald-100/60', 'activo' => 'from-emerald-600/30', 'acento' => 'text-amber-300',
                    'barra' => 'bg-amber-300', 'titulo' => 'text-emerald-200/30', 'borde' => 'via-amber-300/30']
      $pie       = texto del pie

    - Los grupos funcionan como acordeón: solo uno abierto; por defecto el que contiene la pantalla actual.
    - En escritorio el menú se puede contraer a una barra de íconos (se recuerda en la cookie sb_colapsado).
--}}
@php
    $u = auth()->user();
    $activo = fn ($patron) => request()->routeIs(...(array) $patron);
    // Ítem: [permiso|null, ruta, patrón(es), icono, texto, parámetros de ruta opcionales]
    $url = fn ($i) => route($i[1], $i[5] ?? []);
    $esActivo = fn ($i) => isset($i[5]) ? request()->url() === $url($i) : $activo($i[2]);

    // Solo los ítems permitidos
    $permitido = fn ($i) => $i[0] === null || $u->can($i[0]);
    $principal = collect($principal)->filter($permitido)->values();
    $grupos = collect($grupos)
        ->map(fn ($g) => array_merge($g, ['items' => collect($g['items'])->filter($permitido)->values()]))
        ->filter(fn ($g) => $g['items']->isNotEmpty());

    $grupoActivo = $grupos->search(fn ($g) => $g['items']->contains(fn ($i) => $esActivo($i)));
    $ids = $grupos->keys()->mapWithKeys(fn ($t) => [$t => 'g' . substr(md5($t), 0, 6)]);
@endphp

<aside :class="[sidebarOpen ? 'translate-x-0' : '-translate-x-full', colapsado ? 'md:w-20' : 'md:w-72']"
       class="app-sidebar fixed inset-y-0 left-0 z-50 flex w-72 flex-col overflow-hidden {{ $tema['texto'] }} transition-all duration-300 ease-in-out md:static md:inset-auto md:translate-x-0 {{ $colapsadoInicial ? 'md:w-20' : 'md:w-72' }}"
       x-data="{ abierto: @js($grupoActivo !== false ? $ids[$grupoActivo] : null) }">

    <!-- Decoración -->
    <div class="pointer-events-none absolute inset-0">
        <div class="absolute -top-24 -left-24 h-72 w-72 rounded-full {{ $tema['blur1'] ?? 'bg-emerald-500/15' }} blur-3xl"></div>
        <div class="absolute -bottom-28 -right-20 h-72 w-72 rounded-full {{ $tema['blur2'] ?? 'bg-amber-400/10' }} blur-3xl"></div>
        <div class="absolute inset-y-0 right-0 w-px bg-gradient-to-b from-transparent {{ $tema['borde'] }} to-transparent"></div>
    </div>

    <!-- Marca -->
    <a href="{{ route($marca['ruta']) }}" class="relative flex h-16 shrink-0 items-center gap-3 px-5" :class="colapsado && 'md:justify-center md:px-0'">
        <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border {{ $tema['marca'] ?? 'border-amber-300/30 bg-amber-300/10 text-amber-300' }}">
            <i class="fa-solid {{ $marca['icono'] }}"></i>
        </div>
        <div class="leading-tight" :class="colapsado && 'md:hidden'">
            <span class="block whitespace-nowrap font-['Playfair_Display'] text-lg font-semibold tracking-wide text-white">{!! $marca['titulo'] !!}</span>
            <span class="block whitespace-nowrap text-[10px] uppercase tracking-[0.3em] {{ $tema['titulo'] }}">{{ $marca['subtitulo'] }}</span>
        </div>
    </a>
    <div class="relative mx-5 h-px shrink-0 bg-gradient-to-r from-white/20 via-white/5 to-transparent"></div>

    <!-- Navegación -->
    <nav class="relative flex-1 space-y-1 overflow-y-auto overflow-x-hidden px-3 py-3">
        {{-- Accesos principales (siempre visibles) --}}
        @foreach ($principal as [$permiso, $ruta, $patron, $icono, $texto])
            @php $act = $activo($patron); @endphp
            <a href="{{ route($ruta) }}" title="{{ $texto }}"
               class="group relative flex items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition
                      {{ $act ? 'bg-gradient-to-r ' . $tema['activo'] . ' to-transparent text-white font-semibold' : 'hover:bg-white/5 hover:text-white' }}"
               :class="colapsado && 'md:justify-center md:px-0'">
                @if ($act)<span class="absolute left-0 top-1/2 h-6 w-1 -translate-y-1/2 rounded-r-full {{ $tema['barra'] }}"></span>@endif
                <i class="fa-solid {{ $icono }} w-5 shrink-0 text-center {{ $act ? $tema['acento'] : '' }}"></i>
                <span class="truncate" :class="colapsado && 'md:hidden'">{{ $texto }}</span>
            </a>
        @endforeach

        <div class="my-2 h-px bg-white/5"></div>

        {{-- Grupos plegables --}}
        @foreach ($grupos as $titulo => $g)
            @php
                $id = $ids[$titulo];
                $tieneActivo = $grupoActivo === $titulo;
            @endphp
            <div>
                <button type="button" title="{{ $titulo }}"
                        @click="if (colapsado) { alternarSidebar(); abierto = '{{ $id }}' } else { abierto = (abierto === '{{ $id }}' ? null : '{{ $id }}') }"
                        class="group flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left text-sm font-medium transition hover:bg-white/5 hover:text-white {{ $tieneActivo ? 'text-white' : '' }}"
                        :class="colapsado && 'md:justify-center md:px-0'">
                    <span class="relative w-5 shrink-0 text-center">
                        <i class="fa-solid {{ $g['icono'] }} {{ $tieneActivo ? $tema['acento'] : '' }}"></i>
                        @if ($tieneActivo)<span class="absolute -right-1 -top-1 hidden h-2 w-2 rounded-full {{ $tema['barra'] }}" :class="colapsado && 'md:block'"></span>@endif
                    </span>
                    <span class="flex-1 truncate" :class="colapsado && 'md:hidden'">{{ $titulo }}</span>
                    <i class="fa-solid fa-chevron-down text-[10px] opacity-50 transition-transform duration-200" :class="[abierto === '{{ $id }}' && 'rotate-180', colapsado && 'md:hidden']"></i>
                </button>

                <div x-show="abierto === '{{ $id }}' && !colapsado" x-transition.opacity.duration.150ms {{ $tieneActivo ? '' : 'x-cloak' }}
                     class="ml-5 space-y-0.5 border-l border-white/10 py-1 pl-3">
                    @foreach ($g['items'] as $it)
                        @php [$permiso, $ruta, $patron, $icono, $texto] = $it; $act = $esActivo($it); @endphp
                        <a href="{{ $url($it) }}"
                           class="flex items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-[13px] transition {{ $act ? 'bg-white/10 text-white font-semibold' : 'opacity-80 hover:bg-white/5 hover:text-white hover:opacity-100' }}">
                            <i class="fa-solid {{ $icono }} w-4 text-center text-xs {{ $act ? $tema['acento'] : 'opacity-70' }}"></i>
                            <span class="truncate">{{ $texto }}</span>
                        </a>
                    @endforeach
                </div>
            </div>
        @endforeach
    </nav>

    <!-- Pie: contraer / expandir -->
    <div class="relative shrink-0 border-t border-white/5 p-3">
        <p class="mb-2 truncate px-2 text-[10px] uppercase tracking-[0.25em] {{ $tema['titulo'] }}" :class="colapsado && 'md:hidden'">{{ $pie }}</p>
        <button type="button" @click="alternarSidebar()"
                class="hidden w-full items-center gap-3 rounded-xl px-3 py-2 text-xs font-semibold transition hover:bg-white/5 hover:text-white md:flex"
                :class="colapsado && 'md:justify-center md:px-0'" :title="colapsado ? 'Expandir menú' : 'Contraer menú'">
            <i class="fa-solid w-5 text-center" :class="colapsado ? 'fa-angles-right' : 'fa-angles-left'"></i>
            <span :class="colapsado && 'md:hidden'">Contraer menú</span>
        </button>
    </div>
</aside>
