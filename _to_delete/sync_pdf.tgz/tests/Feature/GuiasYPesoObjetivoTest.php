<?php

namespace Tests\Feature;

use App\Models\Ganaderia\PesoObjetivo;
use App\Models\Ganado\FacturaGanado;
use App\Models\Ganado\Ganado;
use App\Models\Ganado\ProveedorGanado;
use App\Models\User;
use App\Services\LiquidacionService;
use App\Services\PesajeService;
use Database\Seeders\RolesYPermisosSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class GuiasYPesoObjetivoTest extends TestCase
{
    use RefreshDatabase;

    private User $jefe;
    private ProveedorGanado $prov;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RolesYPermisosSeeder::class);
        $this->jefe = User::factory()->create();
        $this->jefe->assignRole('gerente');
        $this->jefe->givePermissionTo('planta.ganaderia');
        $this->prov = ProveedorGanado::create(['nombreProveedor' => 'Rancho Las Palmas', 'nombreContacto' => 'José']);
        $this->actingAs($this->jefe)->post(route('plantas.cambiar'), ['planta' => 'ganaderia']);
    }

    private function guia(string $num, string $estado, string $fecha): FacturaGanado
    {
        return FacturaGanado::create(['proveedorID' => $this->prov->id, 'fechaFactura' => $fecha, 'numeroFactura' => $num, 'estado' => $estado]);
    }

    public function test_filtros_de_guias_y_cambio_de_numero(): void
    {
        $g1 = $this->guia('G-100', 'pendiente', now()->subDays(5)->toDateString());
        $this->guia('G-200', 'liquidado', now()->subDays(40)->toDateString());
        $this->guia('G-300', 'liquidado', now()->subDays(2)->toDateString());

        $this->get(route('proveedores.facturas.index'))->assertOk()->assertSee('G-100')->assertDontSee('G-200');
        $this->get(route('proveedores.facturas.index', ['estado' => 'liquidadas']))->assertSee('G-200')->assertSee('G-300')->assertDontSee('G-100');
        $this->get(route('proveedores.facturas.index', ['estado' => 'liquidadas', 'desde' => now()->subDays(10)->toDateString()]))
            ->assertSee('G-300')->assertDontSee('G-200');
        $this->get(route('proveedores.facturas.index', ['estado' => 'todas', 'q' => 'Palmas']))->assertSee('G-100')->assertSee('G-300');

        // El número es solo texto: el ganado sigue ligado por id
        $animal = Ganado::create(['facturaID' => $g1->id, 'areteID' => 'A-1', 'categoria' => 'Torete', 'pesoActual' => 300, 'ultimoPeso' => 300,
            'precioCompra' => 60, 'fechaCompra' => now()->subDays(5)->toDateString(), 'status' => 'Activo']);
        $this->put(route('proveedores.facturas.numero', $g1->id), ['numero' => 'REEMO-26-445'])->assertSessionHas('success');
        $this->assertSame('REEMO-26-445', $g1->fresh()->numeroFactura);
        $this->assertSame($g1->id, $animal->fresh()->facturaID);
        $this->put(route('proveedores.facturas.numero', $g1->id), ['numero' => 'G-200'])->assertSessionHasErrors('numero');
    }

    public function test_monto_de_compra_no_cambia_con_los_pesajes(): void
    {
        $g = $this->guia('G-1', 'pendiente', now()->subDays(30)->toDateString());
        $a = Ganado::create(['facturaID' => $g->id, 'areteID' => 'A-9', 'categoria' => 'Torete', 'pesoActual' => 300, 'ultimoPeso' => 300,
            'precioCompra' => 60, 'fechaCompra' => now()->subDays(30)->toDateString(), 'status' => 'Activo']);
        app(PesajeService::class)->registrarPesaje($a->GanadoID, 345, now()->toDateString());

        $this->assertEquals(345, (float) $a->fresh()->ultimoPeso);
        $this->assertEquals(18000, $a->fresh()->precioGanadoTotal);                 // 300 kg × $60
        $this->assertEquals(18000, app(LiquidacionService::class)->calcularResumenFactura($g->id)['totalGanado']);
        $this->get(route('proveedores.facturas.index'))->assertSee('18,000.00');
    }

    public function test_peso_objetivo_por_categoria_configurable(): void
    {
        $g = $this->guia('G-2', 'pendiente', now()->toDateString());
        $a = Ganado::create(['facturaID' => $g->id, 'areteID' => 'B-1', 'categoria' => 'Becerro', 'pesoActual' => 230, 'ultimoPeso' => 230,
            'precioCompra' => 70, 'fechaCompra' => now()->toDateString(), 'status' => 'Activo']);
        $this->assertTrue($a->esta_listo_venta);   // de fábrica: 220

        $pesos = ['Becerro' => 260, 'Torete' => 450, 'Toro' => 500, 'Becerra' => 240, 'Vaquilla' => 380, 'Vaca' => 420];
        $this->put(route('ganado.pesos-objetivo'), ['pesos' => $pesos])->assertSessionHas('success');
        PesoObjetivo::limpiarCache();

        $this->assertEquals(260, $a->fresh()->peso_objetivo_calculado);
        $this->assertFalse($a->fresh()->esta_listo_venta);
        $this->assertSame(0, Ganado::listoParaVenta()->count());

        // Un peso propio en la ficha manda sobre el de la categoría
        $a->update(['peso_objetivo' => 225]);
        $this->assertEquals(225, $a->fresh()->peso_objetivo_calculado);

        $this->put(route('ganado.pesos-objetivo'), ['pesos' => ['Becerro' => 10] + $pesos])->assertSessionHasErrors('pesos.Becerro');
        $this->get(route('compras.ganado.index'))->assertOk()->assertSee('Peso objetivo');
    }

    public function test_liquidacion_muestra_promedios_y_no_se_liquida_dos_veces(): void
    {
        $g = $this->guia('G-L', 'pendiente', now()->subDays(3)->toDateString());
        foreach ([[200, 90], [300, 80]] as $i => [$kg, $p]) {
            Ganado::create(['facturaID' => $g->id, 'areteID' => "T-{$i}", 'categoria' => 'Torete', 'pesoActual' => $kg, 'ultimoPeso' => $kg,
                'precioCompra' => $p, 'fechaCompra' => now()->subDays(3)->toDateString(), 'status' => 'Activo']);
        }
        // Total 18,000 + 24,000 = 42,000 · 500 kg · precio promedio ponderado 84.00 · peso promedio 250
        $this->get(route('proveedores.facturas.liquidar', $g->id))->assertOk()
            ->assertSee('42,000.00')->assertSee('84.00')->assertSee('250.0 kg')->assertSee('Rancho Las Palmas');

        $this->post(route('proveedores.facturas.liquidar.pago', $g->id))->assertRedirect(route('proveedores.facturas.liquidar.exito', $g->id));
        $this->assertSame('liquidado', $g->fresh()->estado);

        $this->get(route('proveedores.facturas.liquidar', $g->id))->assertOk()->assertSee('ya fue liquidada')->assertDontSee('Confirmar pago y generar PDF');
        $this->get(route('proveedores.facturas.liquidar.generarPdf', $g->id))->assertOk();
        $this->post(route('proveedores.facturas.liquidar.pago', $g->id))->assertSessionHas('aviso');
    }

    public function test_anticipo_aplicado_se_ve_despues_de_liquidar_y_reemo(): void
    {
        $g = $this->guia('G-A', 'pendiente', now()->toDateString());
        $g->update(['guia_reemo' => 'RM-26-111222']);
        Ganado::create(['facturaID' => $g->id, 'areteID' => 'X-1', 'categoria' => 'Torete', 'pesoActual' => 200, 'ultimoPeso' => 200,
            'precioCompra' => 90, 'fechaCompra' => now()->toDateString(), 'status' => 'Activo']);
        $ad = \App\Models\Ganado\Adelanto::create(['proveedor_id' => $this->prov->id, 'concepto' => 'Anticipo de compra', 'dinero' => 5000, 'date' => now()->toDateString(), 'status' => 'entregado']);

        $this->get(route('proveedores.facturas.liquidar', $g->id))->assertSee('RM-26-111222')->assertSee('Anticipo de compra');
        $this->post(route('proveedores.facturas.liquidar.pago', $g->id), ['adelantos' => [$ad->id]]);

        $r = app(LiquidacionService::class)->calcularResumenFactura($g->id);
        $this->assertEquals(5000, $r['totalAdelantos']);
        $this->assertEquals(13000, $r['montoAbsoluto']);
        $this->get(route('proveedores.facturas.liquidar', $g->id))->assertSee('Anticipo de compra')->assertSee('Anticipos aplicados');
    }
}
